public interface IntToIntFuncIF {
    int func(int x);
}
