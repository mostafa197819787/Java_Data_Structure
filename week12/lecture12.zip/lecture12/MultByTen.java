public class MultByTen implements IntToIntFuncIF {

    /** @return ten times the int argument */
    public int func(int x) {
        return 10 * x;
    }

}
