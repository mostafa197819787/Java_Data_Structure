public class ARDeque<T> {
	
	// Copy Paste your ARDeque implementation from Lab 8 here !
	
	

}