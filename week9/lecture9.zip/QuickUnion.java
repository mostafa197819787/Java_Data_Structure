public class QuickUnion {

    private int[] parent;

    /** Construct a new union find data structure of N elements. */
    public QuickUnion(int N) {
        parent = new int[N];
        for (int i = 0; i < N; i++) {
            parent[i] = -1;
        }
    }

    // Finding the root.
    private int find(int p) {
        while (parent[p] >= 0) {
            p = parent[p];
        }
        return p;
    }

    /** Combines two elements p and q. */
    public void union(int p, int q) {
        int i = find(p);
        int j = find(q);
        parent[i] = j;
    }

    /** Decides if two elements p and q are in the same group. */
    public boolean isSameGroup(int p, int q) {
        return find(p) == find(q);
    }
}

