// LAB EXERCISE 10.1  DEQUE INTERFACE

// Complete the interface for Deque
// to be implemented by ARDeque

public ... {
	
	
	
}
