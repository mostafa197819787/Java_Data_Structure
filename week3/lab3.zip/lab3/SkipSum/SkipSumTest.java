
public class SkipSumTest {
    
	
	
}
