
public class OddAndTenTest {
    
	
	
}
